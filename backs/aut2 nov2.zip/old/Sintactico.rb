
class Sintactico
  con = 0
  con2 = 2
  ListaTokens = [Tokens]()


  def initialize(Lista: [tokens])
    @ListaTokens = Lista
  end

  def Inicio ()
    while con != ListaTokens.Lenght do |variable|

    end

end
