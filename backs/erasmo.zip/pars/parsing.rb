require 'parslet'
include Parslet

class MyOwn < Parslet::Parser
  # chars
  rule(:parenIz)      { str('(')  >>  espacio?  }
  rule(:parenDer)     { str(')')  >>  espacio?  }
  rule(:coma)         { str(',')  >>  espacio?  }
  rule(:quadDer)      { str(']')  >>  espacio?  }
  rule(:quadIz)       { str('[')  >>  espacio?  }
  rule(:pYc)          { str(';')  >>  espacio?  }
  rule(:dosPuntos)    { str(':')  >>  espacio?  }

  # operadores
  rule(:mas)        { match('[+]')  >>  espacio?  }
  rule(:menos)      { match('[-]')  >>  espacio?  }
  rule(:division)   { match('[/]')  >>  espacio?  }
  rule(:operador)   { mas|menos|division  }
  rule(:AND)        { match('and')  >>  espacio?  }
  rule(:OR)         { match('or')   >>  espacio?  }
  rule(:extras)     { AND | OR  }

#operadores logicos
  rule(:igual)      { match('==')   >>  espacio? }
  rule(:distinto)   { match('!=')   >>  espacio? }
  rule(:mayorQue)   { match('>')    >>  espacio? }
  rule(:menorQue)   { match('<')    >>  espacio? }
  rule(:mayorigual) { match('>=')   >>  espacio? }
  rule(:menorIgual) { match('<=')   >>  espacio? }
  rule(:OpLogicos)  { igual | distinto  | mayorQue  | menorQue  | mayorigual  | menorIgual  }

  #espacios
  rule(:espacio)      { match('\s').repeat(1)  }
  rule(:espacio?)     { espacio.maybe }

  # objetos
  rule(:digito)       { match('[0-9]').repeat(1) >> espacio?  }
  rule(:entero)       { match('[1-9]')  >> digito.repeat(0) }

  rule(:identificador)  { match(['a-zA-z']).repeat(1) >>  match('\w').repeat(0)  }

  #palabras
  rule(:nil)          { match('nil')  >>  espacio?  }
  rule(:si)           { match('if')   >>  espacio?  }
  rule(:para)         { match('for')  >>  espacio?  }
  rule(:entonces)     { match('then') >>  espacio?  }
# sintaxis
  rule(:operacion)    { (entero).as(:izqueirdo) >>  operador.as(:op)  >>  instruccion.as(:derecho)  }
  rule(:lista_op)     { instruccion >> (coma  >> instruccion).repeat }
  rule(:operaciones)  { identificador.as(:funcion)  >>  parenIz >>  lista_op.as(:lista) >>  parenDer  }
# condicion
  rule(:condicion)    { identificador|entero  >>  (OpLogicos  >>  identificador|entero).repeat(0) }
  rule(:condiciones)  { condicion >>  (extras  >>  condicion).repeat(0) }
  rule(:condicionF)   { condiciones >>  dosPuntos }
#BLOQUE?rule(:condicion)    { identificador | entero  >>  (bloque >> pYc).as(:instruccion)  >>  }

  #bloque de codigo (DEFINIR BLOQUE)

  #instrucciones
  rule(:instSi)       { (si).as(:inicio)  >>   condicionF  >> entonces }

  rule(:instruccion)       { operaciones | operacion | entero }
  root :instruccion
  # falta construir el bloque
end

require 'pp'
pp MyOwn.new.parse("32 +23")
